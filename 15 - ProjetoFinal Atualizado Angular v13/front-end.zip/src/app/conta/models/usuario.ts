export interface Usuario {
    id: string;
    email: string;
    password: string;
    confirmPassword: string;
}