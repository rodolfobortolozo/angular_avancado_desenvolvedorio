import { Component } from '@angular/core';

@Component({
  selector: 'app-acesso-negado',
  templateUrl: './acesso-negado.component.html'
})
export class AcessoNegadoComponent  { }
