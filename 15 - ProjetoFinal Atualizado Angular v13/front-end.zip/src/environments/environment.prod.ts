export const environment = {
  production: true,
  apiUrlv1: 'http://localhost:5001/api/v1/',
  imagensUrl: 'http://localhost:5001/'
};
